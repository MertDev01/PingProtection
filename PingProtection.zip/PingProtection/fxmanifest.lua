fx_version "cerulean"
game "gta5"
use_fxv2_oal "yes"
lua54 "yes"


version "1.0.0"

server_scripts { "server.lua" }

